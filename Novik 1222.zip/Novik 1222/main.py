import math
a = 10
b = 5.1
c = 2
sum=a+b+c
vcht=a-b-c
umn=a*b*c
dln=a/b/c
print(sum)
print(vcht)
print(umn)
print(dln)
print(math.factorial(a))
print(math.sqrt(c))
print(math.floor(b))
print(math.log(8,2))
print(c**10)



# import telebot
# bot = telebot.TeleBot('6224527681:AAE89ZE3XDYlFvcymfoSi49Dfb0qb78JEQo')
# @bot.message_handler(commands=["start"])
# def start(m, res=False):
#     bot.send_message(m.chat.id, 'Я на связи. Напиши мне что-нибудь )')
# @bot.message_handler(content_types=["text"])
# def handle_text(message):
#     bot.send_message(message.chat.id, 'Вы написали: ' + message.text)
#
# bot.polling(none_stop=True, interval=0)




import telebot
import random
#
# bot = telebot.TeleBot('6224527681:AAE89ZE3XDYlFvcymfoSi49Dfb0qb78JEQo')
#
# colors=['Красный','Синий','Белый','Оранжевый','Зелёный','Жёлтый']
# colorsreturn=[]
# for item in colors:
#     colorsreturn.append(item)
#
# str=''
#
# item=''
#
#
# @bot.message_handler(commands=["start"])
# def start(m, res=False):
#     bot.send_message(m.chat.id, 'Нажмите 1 чтобы зарандомить:\nНажмите 2 чтобы добавить элемент:\nНажмите 3 '
#                                 'чтобы удалить элемент:')
#
#
# @bot.message_handler(content_types=["text"])
# def handle_text(message):
#     if message.text == '1':
#         bot.send_message(message.chat.id, 'Я зарандомил: ' + RandomElement())
#     if message.text == '2':
#         bot.send_message(message.chat.id, 'Напишите цвет ')
#         bot.register_next_step_handler(message,AddElement)
#     if message.text == '3':
#         bot.send_message(message.chat.id, 'Напишите цвет, который надо удалить')
#         bot.register_next_step_handler(message, RemoveElement)
#
# def RandomElement():
#     if len(colorsreturn)!=0:
#         index = random.randint(0, len(colorsreturn) - 1)
#         str = colorsreturn[index]
#         colorsreturn.remove(colorsreturn[index])
#         return str
#     else:
#         for item in colors:
#             colorsreturn.append(item)
#         index = random.randint(0, len(colorsreturn) - 1)
#         str = colorsreturn[index]
#         colorsreturn.remove(colorsreturn[index])
#         return str
#
# def AddElement(message):
#     global item
#     item=message.text
#     if not colors.__contains__(item):
#         colors.append(item)
#         colorsreturn.append(item)
#         bot.send_message(message.from_user.id, f'Добавил цвет {message.text}');
#     else:
#         bot.send_message(message.chat.id, f'Цвет {message.text} существует, напишите новый')
#         bot.register_next_step_handler(message,AddElement)
#
# def RemoveElement(message):
#     global item
#     item = message.text
#     if colors.__contains__(item):
#         colors.remove(item)
#         colorsreturn.remove(item)
#         bot.send_message(message.from_user.id, f'Удалил цвет {message.text}');
#     else:
#         bot.send_message(message.from_user.id, f'Цвета не существует в списке, хотите добавлю?(Скажите да)');
#         bot.register_next_step_handler(message, AddElement)
#
# bot.polling(none_stop=True, interval=0)

photki = ['http://fototelegraf.ru/wp-content/uploads/2016/06/sobaki-30-5.jpg', 'https://кутята.рф/media/dv/2019/7/223351-2019-09-06_13-57-12.758439.jpg',
          'https://avatars.mds.yandex.net/i?id=f2a800bd873669ea9669d9f9677f53a4-5392430-images-thumbs&ref=rim&n=13&w=640&h=640', 'https://cs14.pikabu.ru/post_img/2021/10/07/7/1633605973152433535.webpН']
bot = telebot.TeleBot('6224527681:AAE89ZE3XDYlFvcymfoSi49Dfb0qb78JEQo')

@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Данёк пёс?\nДа/Нет')


@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == 'Да':
        bot.send_message(message.chat.id, 'Вы правы ')
    elif message.text == 'Нет':
        bot.send_message(message.chat.id, 'Вы пёс')
        bot.send_photo(message.chat.id, random.choice(photki))
    else:
        bot.send_message(message.chat.id, 'Я Вас не понял')

bot.polling(none_stop=True, interval=0)


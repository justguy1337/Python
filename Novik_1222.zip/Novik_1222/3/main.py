import math
print('Инд. задание')
a = int(input('Введите a: '))
b = int(input('Введите b: '))
z1 = math.sin((math.pi/2)+ 3*a) / 1 - math.sin(3*a - math.pi)
print('Первый ответ:', z1)
z2 = 1/math.tan(5/4*math.pi + 3/2*a)
print('Второй ответ:', z2)
#повышенное
print('Повышенное')
x = int(input('Введите x: '))
y = int(input('Введите y: '))
z = int(input('Введите z: '))
e = int(input('Введите e: '))
h = (x**(y+1) + e**(y-1)) / 1 + x * abs(y-math.tan(z)) * (1+abs(y-x)) + (abs(y-x)**2) / 2 - (abs(y-x)**3) / 3
print('Ответ:', h)
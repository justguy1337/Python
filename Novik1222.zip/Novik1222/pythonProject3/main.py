a = int(input())
b = int(input())
h = int(input())
print(a)
while a < b:
    a = a + h
    if a > b:
        break
    print(a)

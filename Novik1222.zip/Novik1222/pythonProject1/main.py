import math
chisl = int(input())
r = 0
e = 0
for i in chisl:
    if i % 2 == 0:
        z = r + i
    else:
        y = i + e
print(z)
print(y)

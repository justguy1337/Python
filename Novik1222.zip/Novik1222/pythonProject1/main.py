x = int(input())
y = int(input())
z = int(input())
if y > z:
    max1 = y
elif y < z:
    max1 = z
if x < y
    min1 = x
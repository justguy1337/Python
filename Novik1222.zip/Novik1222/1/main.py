import math
#повышенное
a = int(input())
b = int(input())
h = int(input())
k = 1
sum = 0
while a <= b:
    s = (-1)**(k+1) * (a**(2*k+1)/4*k**2 - 1)
    sum = sum + s
    y = (1 + a ** 2 / 2) * math.atan(a) - a / 2
    a = a + h
    t = math.fabs(y-sum)
    print(f"{s} значение s, {sum} сумма, {y} значение y, {t} разность s и y")







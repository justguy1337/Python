import math
a = 100
b = 50
c = 20
r = 100
result = a == c
print(result)
print(b != c)
print(a > b)
print(a >= r)
print(b >= r)
print('Оператор and')
res = a > 60 and b == 50
print(res)
res = a == 90 or c <= 15
print(res)
print(not c <= 12)
print('Оператор in')
rt = 'black slaves'
tr = 'black'
print(tr in rt)
print(rt in tr)
print('Конструкция if')
print('Введите имя')
name = input()
age = int(input())
if name == 'boris':
    print('johnson')
    if age == 54:
        print('president')
    else:
        print('nigger')
elif name == 'walter':
    print('white')
else:
    print('error')
#Индивидуальное задание
x = int(input('Введите x: '))
y = int(input('Введите y: '))
z = int(input('Введите z: '))
if z <= 0:
    z = z**b + math.log(b/2)
elif z > 0:
    z = math.sqrt(z)
else:
    print('Ошибка')
y = 1 / math.cos(x) + math.log(math.tan(x/2))
print('Ответ:', y)


import math
a = int(input('Введите первое число: '))
b = int(input('Введите второе число: '))
x = int
operat = input('Введите знак операции(*, /, +, -): ')
if b>0 or b<0:
    if operat == "*":
        x = a * b
        print(x)
    elif operat == "+":
        x = a + b
        print(x)
    elif operat == "-":
        x = a - b
        print(x)
    elif operat == "/":
        x = a / b
        print(x)
    elif operat == "0":
        print('0 нельзя использовать в качестве знака операции')
    else:
        print('Ошибка')
else:
    print("На ноль делить нельзя")




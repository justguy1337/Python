import collections
import random
import time
plst = ['Санкт-Петербург', 'Москва', 'Чикаго', 'Нью-Йорк', 'Осло', 'Лос-Анджелес','Киев', 'Харьков', 'Львов', 'Донецк', 'Ниамей', 'Запорожье', 'Днепр',
        'Белгород', 'Ростов-на-Дону', 'Тверь', 'Тула', 'Владивосток', 'Ереван', 'Арарат', 'Париж', 'Берлин', 'Хиросима', 'Нагасаки', 'Петрозаводск', 'Вашингтон',
        'Баку', 'Анкара', 'Афины', 'Пекин']
list2 = []
def kill_niggers():
        while True:
                x = random.randint(0, 29)
                y = plst[x]
                if y in list2:
                        time.sleep(0.5)
                        print('Элемент уже есть в списке')
                else:
                        time.sleep(0.5)
                        list2.append(y)
                        print(list2)

                if collections.Counter(plst) == collections.Counter(list2):
                        print('Списки содержат одинаковые элементы. Начинаю с начала')
                        list2.clear()
kill_niggers()

